<?php

namespace Solspace\ExpressForms\integrations;

interface MailingListTypeInterface extends IntegrationTypeInterface
{
}
