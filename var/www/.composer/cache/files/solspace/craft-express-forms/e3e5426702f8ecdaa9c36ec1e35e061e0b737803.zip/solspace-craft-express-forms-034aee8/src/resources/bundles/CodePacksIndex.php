<?php

namespace Solspace\ExpressForms\resources\bundles;

class CodePacksIndex extends BaseExpressFormsBundle
{
    public function getScripts(): array
    {
        return ['js/control-panel/code-packs/index.js'];
    }
}
