<?php

namespace Solspace\ExpressForms\exceptions\Integrations;

class ConnectionFailedException extends IntegrationException
{
}
