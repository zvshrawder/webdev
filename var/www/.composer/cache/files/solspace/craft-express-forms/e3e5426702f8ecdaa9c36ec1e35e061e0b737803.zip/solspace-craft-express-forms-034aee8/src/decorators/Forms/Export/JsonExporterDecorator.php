<?php

namespace Solspace\ExpressForms\decorators\Forms\Export;

use function GuzzleHttp\Psr7\rewind_body;
use Solspace\ExpressForms\decorators\AbstractDecorator;
use Solspace\ExpressForms\decorators\ExtraBundle;
use Solspace\ExpressForms\events\export\ExportSubmissionsEvent;
use Solspace\ExpressForms\events\export\RegisterExportTypesEvent;
use Solspace\ExpressForms\services\Export;

class JsonExporterDecorator extends AbstractDecorator implements ExtraBundle
{
    public function getEventListenerList(): array
    {
        return [
            [Export::class, Export::EVENT_REGISTER_EXPORT_TYPES, [$this, 'registerType']],
            [Export::class, Export::EVENT_EXPORT_SUBMISSIONS, [$this, 'exportSubmissions']],
        ];
    }

    /**
     * @param RegisterExportTypesEvent $event
     */
    public function registerType(RegisterExportTypesEvent $event)
    {
        $event->addType('JSON');
    }

    /**
     * @param ExportSubmissionsEvent $event
     */
    public function exportSubmissions(ExportSubmissionsEvent $event)
    {
        if ($event->getType() !== 'json') {
            return;
        }

        $submissions = $event->getSubmissions();
        $content = \GuzzleHttp\json_encode($submissions, JSON_PRETTY_PRINT);

        $fileName = sprintf(
            '%s submissions %s.json',
            $event->getForm()->getName(),
            date('Y-m-d H:i')
        );

        $response = $event->getResponse();
        $response->sendContentAsFile($content, $fileName, ['mimeType' => 'application/json']);
    }
}
