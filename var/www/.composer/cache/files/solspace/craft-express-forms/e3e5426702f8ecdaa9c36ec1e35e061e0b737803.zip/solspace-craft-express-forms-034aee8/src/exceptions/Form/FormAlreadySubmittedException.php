<?php

namespace Solspace\ExpressForms\exceptions\Form;

use Solspace\ExpressForms\exceptions\ExpressFormsException;

class FormAlreadySubmittedException extends ExpressFormsException
{
}
