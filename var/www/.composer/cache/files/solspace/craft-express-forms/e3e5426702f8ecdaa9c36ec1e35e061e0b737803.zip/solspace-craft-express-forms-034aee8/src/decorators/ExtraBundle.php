<?php

namespace Solspace\ExpressForms\decorators;

interface ExtraBundle
{
}
