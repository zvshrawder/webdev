<?php

namespace Solspace\ExpressForms\exceptions\Integrations;

use Solspace\ExpressForms\exceptions\ExpressFormsException;

class IntegrationException extends ExpressFormsException
{
}
