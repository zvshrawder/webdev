<?php

namespace Solspace\ExpressForms\exceptions;

class ExpressFormsException extends \Exception
{
}
