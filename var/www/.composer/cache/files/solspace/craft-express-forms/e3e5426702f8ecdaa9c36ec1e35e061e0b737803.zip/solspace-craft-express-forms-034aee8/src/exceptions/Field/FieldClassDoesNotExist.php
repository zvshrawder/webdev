<?php

namespace Solspace\ExpressForms\exceptions\Field;

use Solspace\ExpressForms\exceptions\ExpressFormsException;

class FieldClassDoesNotExist extends ExpressFormsException
{
}
