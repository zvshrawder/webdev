<?php

namespace Solspace\ExpressForms\exceptions\EmailNotifications;

use Solspace\ExpressForms\exceptions\ExpressFormsException;

class EmailNotificationsException extends ExpressFormsException
{
}
