<?php

namespace Solspace\ExpressForms\fields;

interface MultipleValueInterface
{
}
