<?php

namespace Solspace\ExpressForms\exceptions\EmailNotifications;

class NotificationNotFound extends EmailNotificationsException
{
}
