<?php

namespace Solspace\ExpressForms\exceptions\EmailNotifications;

class CouldNotParseNotificationException extends EmailNotificationsException
{
}
