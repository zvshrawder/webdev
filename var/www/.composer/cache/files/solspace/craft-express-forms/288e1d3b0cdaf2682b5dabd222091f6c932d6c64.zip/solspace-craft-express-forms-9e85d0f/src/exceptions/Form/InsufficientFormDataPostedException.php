<?php

namespace Solspace\ExpressForms\exceptions\Form;

use Solspace\ExpressForms\exceptions\ExpressFormsException;

class InsufficientFormDataPostedException extends ExpressFormsException
{
}
