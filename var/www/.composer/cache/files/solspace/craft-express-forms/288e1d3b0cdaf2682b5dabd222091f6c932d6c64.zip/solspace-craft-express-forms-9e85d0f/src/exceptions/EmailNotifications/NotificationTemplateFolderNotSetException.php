<?php

namespace Solspace\ExpressForms\exceptions\EmailNotifications;

class NotificationTemplateFolderNotSetException extends EmailNotificationsException
{
}
