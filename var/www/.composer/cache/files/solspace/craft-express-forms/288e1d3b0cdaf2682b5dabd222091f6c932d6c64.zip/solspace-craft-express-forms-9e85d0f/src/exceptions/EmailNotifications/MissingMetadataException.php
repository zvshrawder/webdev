<?php

namespace Solspace\ExpressForms\exceptions\EmailNotifications;

class MissingMetadataException extends EmailNotificationsException
{
}
