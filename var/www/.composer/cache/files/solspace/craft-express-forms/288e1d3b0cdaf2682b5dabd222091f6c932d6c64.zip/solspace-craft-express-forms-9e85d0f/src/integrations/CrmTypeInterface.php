<?php

namespace Solspace\ExpressForms\integrations;

interface CrmTypeInterface extends IntegrationTypeInterface
{
}
