# Solspace Commons Library for Craft CMS 3 plugins

Solspace Commons is a layer of functionality used across several Solspace plugins for Craft CMS to prevent code duplication. It contains a collection of helper objects and functions which provide better ways to develop for Craft CMS 3 and Yii PHP framework. While used primarily by Solspace, it's under the MIT license and available for other developers.
