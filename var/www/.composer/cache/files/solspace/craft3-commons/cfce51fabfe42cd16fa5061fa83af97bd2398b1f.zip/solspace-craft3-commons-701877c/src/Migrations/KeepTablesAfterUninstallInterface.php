<?php

namespace Solspace\Commons\Migrations;

interface KeepTablesAfterUninstallInterface
{
}
