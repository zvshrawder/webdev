<?php

namespace Solspace\Commons\Exceptions;

use yii\db\Exception;

class BaseException extends Exception
{
}
