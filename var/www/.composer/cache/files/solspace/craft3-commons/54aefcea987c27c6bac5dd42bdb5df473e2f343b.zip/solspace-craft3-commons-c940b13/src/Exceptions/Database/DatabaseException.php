<?php

namespace Solspace\Commons\Exceptions\Database;

use Solspace\Commons\Exceptions\BaseException;

class DatabaseException extends BaseException
{
}
