<?php
/**
 * Created by PhpStorm.
 * User: gustavs
 * Date: 26/02/2018
 * Time: 12:10
 */

namespace Solspace\Commons\Exceptions\Configurations;

use Solspace\Commons\Exceptions\BaseException;

class ConfigurationException extends BaseException
{
}
