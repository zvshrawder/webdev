# Planning Your Craft Site

* Some tips on how to think about Craft when you plan your site
* Some general advice on apporoaches to developing a site with Craft
* How to approach working with HTML templates in Craft
* This is not a themed CMS - you need to think about it as static templates first and then implement those in Craft
* Take time to plan out your content before getting started. Modeling content in Craft is straight-forward but it's helpful to do it on paper or outside of Craft first in order to avoid making mistakes that will be hard to fix after you're done implementing the site.
*
