<?php

return [
    'components' => [
        'fixture' => [
            'class' => 'system.test.CDbFixtureManager',
        ],
        'request'
    ],
];
