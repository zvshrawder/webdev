# テンプレートの実例

Craft の一般的な使用例です。

- [Disqus の統合](integrating-disqus.md)
- [RSS フィード](rss-feed.md)
- [Atom フィード](atom-feed.md)
- [エントリの投稿フォーム](entry-form.md)
- [検索フォーム](search-form.md)
- [ログインフォーム](login-form.md)
- [ユーザープロフィールの編集フォーム](user-profile-form.md)
- [ユーザー登録フォーム](user-registration-form.md)
- [パスワードを忘れた際のフォーム](forgot-password-form.md)
- [パスワードの設定フォーム](set-password-form.md)

