# エレメント

- [アセット](api:craft\elements\Asset)
- [カテゴリ](api:craft\elements\Category)
- [エントリ](api:craft\elements\Entry)
- [グローバル設定](api:craft\elements\GlobalSet)
- [行列ブロック](api:craft\elements\MatrixBlock)
- [タグ](api:craft\elements\Tag)
- [ユーザー](api:craft\elements\User)

