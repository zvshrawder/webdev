# Template Examples

Some common usage examples in Craft:

- [Integrating Disqus](integrating-disqus.md)
- [RSS Feed](rss-feed.md)
- [Atom Feed](atom-feed.md)
- [Entry Form](entry-form.md)
- [Search Form](search-form.md)
- [Login Form](login-form.md)
- [User Profile Form](user-profile-form.md)
- [User Registration Form](user-registration-form.md)
- [Forgot Password Form](forgot-password-form.md)
- [Set Password Form](set-password-form.md)
