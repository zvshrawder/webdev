# Tags

In addition to the template tags that [Twig comes with](https://twig.symfony.com/doc/tags/index.html), Craft provides a few of its own.

- [cache](tags/cache.md)
- [css](tags/css.md)
- [exit](tags/exit.md)
- [header](tags/header.md)
- [hook](tags/hook.md)
- [js](tags/js.md)
- [nav](tags/nav.md)
- [paginate](tags/paginate.md)
- [redirect](tags/redirect.md)
- [requireLogin](tags/requirelogin.md)
- [requirePermission](tags/requirepermission.md)
- [switch](tags/switch.md)
