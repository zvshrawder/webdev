# Elements

- [Asset](api:craft\elements\Asset)
- [Category](api:craft\elements\Category)
- [Entry](api:craft\elements\Entry)
- [GlobalSet](api:craft\elements\GlobalSet)
- [MatrixBlock](api:craft\elements\MatrixBlock)
- [Tag](api:craft\elements\Tag)
- [User](api:craft\elements\User)
