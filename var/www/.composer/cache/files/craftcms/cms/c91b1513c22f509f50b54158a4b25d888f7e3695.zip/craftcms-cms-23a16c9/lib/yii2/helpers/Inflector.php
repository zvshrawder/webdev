<?php
/**
 * @link https://craftcms.com/
 * @copyright Copyright (c) Pixel & Tonic, Inc.
 * @license https://craftcms.github.io/license/
 */

namespace yii\helpers;

/**
 * @inheritdoc
 */
class Inflector extends BaseInflector
{
}
