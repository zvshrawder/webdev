# Craft Server Check

This script checks if a web server meets the minimum requirements to run a Craft 3 installation.

You can upload the `server` folder to your web server's public html folder and load `checkit.php` from your browser
or upload `server` anywhere on your server and execute `php checkit.php` from the console to see the results.
