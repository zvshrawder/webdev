<?php
/**
 * Created by PhpStorm.
 * User: lucasweijers
 * Date: 09-06-17
 * Time: 15:39
 */

?>

<div class="form__thanks">
  <p>Thank you, we will contact you soon.</p>
</div>




