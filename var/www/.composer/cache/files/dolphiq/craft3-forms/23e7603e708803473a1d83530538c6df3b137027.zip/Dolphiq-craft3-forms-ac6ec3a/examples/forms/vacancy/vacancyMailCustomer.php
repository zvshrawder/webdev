<?php

/* @var $this \yii\web\View view component instance */
/* @var $message \yii\mail\BaseMessage instance of newly created mail message */
/* @var $model app\forms\vacancyForm */

?>
<h2>Thank you for your message <?= $model->lastname; ?></h2>
<p>
  We will contact you as soon as possible
</p>