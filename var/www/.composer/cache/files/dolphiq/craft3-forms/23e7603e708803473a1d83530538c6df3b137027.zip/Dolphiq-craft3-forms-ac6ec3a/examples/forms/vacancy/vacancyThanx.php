<?php

/**
 * @var $model app\forms\vacancyForm
 * @var $handle string
 */

?>

<p>Thank you <?= $model->firstname; ?>! We will contact you soon.</p>

