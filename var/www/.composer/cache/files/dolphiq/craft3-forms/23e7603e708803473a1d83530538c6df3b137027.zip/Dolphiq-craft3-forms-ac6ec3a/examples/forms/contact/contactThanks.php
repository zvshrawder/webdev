<?php
/**
 * @var $model \app\forms\contactForm
 */
?>

<p>Thank you <?= $model->firstname ?>, we will contact you soon</p>
