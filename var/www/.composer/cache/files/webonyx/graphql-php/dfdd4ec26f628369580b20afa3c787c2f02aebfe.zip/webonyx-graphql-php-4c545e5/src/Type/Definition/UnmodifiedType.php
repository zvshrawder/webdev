<?php
namespace GraphQL\Type\Definition;

/*
export type GraphQLUnmodifiedType =
GraphQLScalarType |
GraphQLObjectType |
GraphQLInterfaceType |
GraphQLUnionType |
GraphQLEnumType |
GraphQLInputObjectType;
*/
interface UnmodifiedType
{
}
