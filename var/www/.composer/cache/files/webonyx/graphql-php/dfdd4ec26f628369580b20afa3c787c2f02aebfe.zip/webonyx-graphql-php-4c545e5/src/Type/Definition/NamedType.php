<?php
namespace GraphQL\Type\Definition;

/*
export type GraphQLNamedType =
  | GraphQLScalarType
  | GraphQLObjectType
  | GraphQLInterfaceType
  | GraphQLUnionType
  | GraphQLEnumType
  | GraphQLInputObjectType;
 */
interface NamedType
{
}
