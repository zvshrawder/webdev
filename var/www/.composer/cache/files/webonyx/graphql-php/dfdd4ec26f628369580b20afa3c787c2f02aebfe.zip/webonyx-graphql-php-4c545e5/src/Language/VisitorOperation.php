<?php
namespace GraphQL\Language;

class VisitorOperation
{
    public $doBreak;

    public $doContinue;

    public $removeNode;
}
