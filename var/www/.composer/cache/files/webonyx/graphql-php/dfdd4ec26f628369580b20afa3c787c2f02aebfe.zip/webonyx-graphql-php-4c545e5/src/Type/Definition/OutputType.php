<?php
namespace GraphQL\Type\Definition;


/*
GraphQLScalarType |
GraphQLObjectType |
GraphQLInterfaceType |
GraphQLUnionType |
GraphQLEnumType |
GraphQLList |
GraphQLNonNull;
*/
interface OutputType
{
}
