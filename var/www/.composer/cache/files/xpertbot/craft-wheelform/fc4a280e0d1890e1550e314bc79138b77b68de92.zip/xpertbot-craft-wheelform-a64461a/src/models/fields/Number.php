<?php
namespace wheelform\models\fields;

use Craft;

class Number extends BaseFieldType
{
    public $name = "Number";

    public $type = "number";
}
