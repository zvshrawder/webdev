<?php
namespace wheelform\models\fields;

use Craft;

class ListField extends BaseFieldType
{
    public $name = "List";

    public $type = "list";
}
