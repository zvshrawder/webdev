/* global Craft */

export function t(message, category, params) {
    return Craft.t(category, message, params)
}
