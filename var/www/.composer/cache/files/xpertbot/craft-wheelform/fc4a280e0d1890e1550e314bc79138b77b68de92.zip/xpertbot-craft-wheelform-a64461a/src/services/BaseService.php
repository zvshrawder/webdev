<?php
namespace wheelform\services;

use yii\base\BaseObject;

abstract class BaseService extends BaseObject
{

}
