module.exports = {
  parser: false,
  plugins: {
    'postcss-preset-env': {},
    'cssnano': {}
  }
}
