<?php

namespace club\assetrev\exceptions;

use Exception;

class ContinueException extends Exception
{
}
