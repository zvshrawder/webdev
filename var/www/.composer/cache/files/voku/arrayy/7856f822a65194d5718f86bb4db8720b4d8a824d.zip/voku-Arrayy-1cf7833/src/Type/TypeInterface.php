<?php

namespace Arrayy\Type;

interface TypeInterface
{
}
