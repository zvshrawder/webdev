<?php

return [
    'test.de',
    'test.com',
    'test.net',
    'test.org',
    'example.de',
    'example.com',
    'example.net',
    'example.org',
];
