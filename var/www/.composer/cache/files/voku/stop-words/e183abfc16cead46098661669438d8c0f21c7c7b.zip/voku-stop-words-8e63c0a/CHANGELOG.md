# Change log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]

## [2.0.1] - 2018-11-23
### Fix
- switch czech and catalan stopwords | thx@retep007

## [2.0.0] - 2017-11-26
### Changed
- "php": ">=7.0"

## [1.2.0] - 2017-05-22
### Changed
- add more languages

## [1.1.0] - 2017-05-12
### Changed
- add more languages

## [1.0.0] - 2017-05-05
### Changed
- init 
