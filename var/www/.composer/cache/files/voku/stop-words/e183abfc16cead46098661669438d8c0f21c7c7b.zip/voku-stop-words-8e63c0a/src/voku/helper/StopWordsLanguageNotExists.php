<?php

declare(strict_types=1);

namespace voku\helper;

/**
 * PhoneticExceptionLanguageNotExists-Helper-Class
 *
 * @package voku\helper
 */
class StopWordsLanguageNotExists extends \Exception
{
}
