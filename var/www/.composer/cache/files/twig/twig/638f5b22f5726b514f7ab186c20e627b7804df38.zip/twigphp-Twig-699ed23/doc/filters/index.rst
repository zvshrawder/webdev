Filters
=======

.. toctree::
    :maxdepth: 1

    abs
    batch
    capitalize
    column
    convert_encoding
    date
    date_modify
    default
    escape
    filter
    first
    format
    join
    json_encode
    keys
    last
    length
    lower
    map
    merge
    nl2br
    number_format
    raw
    reduce
    replace
    reverse
    round
    slice
    sort
    spaceless
    split
    striptags
    title
    trim
    upper
    url_encode
